# Rizky Max - AI Teman Ngobrol 😎

AI chatbot web sederhana yang bisa kamu deploy ke Vercel, dibikin sama Rizky Max.
Ngobrol santai, gaya gaul, penuh emoji 🧠🔥

## Cara Pakai

1. Tambahkan `OPENAI_API_KEY` di `.env.local`
2. Deploy ke [Vercel](https://vercel.com)
3. Ngobrol sesuka hati 😁

## Teknologi
- Next.js
- OpenAI API
- Hosted on Vercel
